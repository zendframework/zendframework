<?php 

namespace PharModulePharTarGz;

class Module
{}