<?php 

namespace PharModuleZip;

class Module
{}