<?php 

namespace PharModuleTarGz;

class Module
{}