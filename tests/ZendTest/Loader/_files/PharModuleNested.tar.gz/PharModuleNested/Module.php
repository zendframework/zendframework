<?php 

namespace PharModuleNested;

class Module
{}