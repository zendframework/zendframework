<?php 

namespace PharModulePharZip;

class Module
{}